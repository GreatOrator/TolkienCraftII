These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's ruins mod.

Last Updated: 3 Jan 2015

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put them in the following Minecraft installation folders (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\*

So, the contents of the "desert" folder go in "*\.minecraft\mods\resources\ruins\desert" ...

... and the rest goes in "*\.minecraft\mods\resources\ruins\templateparser"

The SandstoneDungeon_1v7v10 template calls OTHER templates -- and all those called templates need to go in the
\templateparser folder, or this won't work.

This is a test of randomization with a "modular" dungeon based around slight variations on a standard dungeon
chamber size (13x13 footprint), with a few swap-out "furnishings" in certain of the rooms.  As with most of my
experiments in this area, Command Blocks will need to be enabled if this is used on a multiplayer server, and there
may be significant lag when someone is exploring and comes across one of these (as the program has to pause and
build all those rooms).

