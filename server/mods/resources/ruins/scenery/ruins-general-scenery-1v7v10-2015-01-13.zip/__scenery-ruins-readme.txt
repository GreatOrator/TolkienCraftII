These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's ruins mod.

Last Updated: 15 Jan 2015
(Updated to fix assorted problems with "preserveBlock" rules)

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put the folders (desert, plains, etc.) in the following Minecraft installation folder (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\

SCENERY:
Structures included in this pack are purely to add a bit of scenery and interest to your Minecraft world, without intentionally introducing 
any more in the way of danger (aside from the usual dangers of dark places where monsters could spawn, or an open fire pit not to be
stepped into).  Hence, there are ruined buildings, and the occasional intact one.  If there are any "treasures" (such as ore), there's some
difficulty in finding or reaching it, but no monster spawners, and no outright traps.  Some of the more curious structures make use of
uniqueMinDistance so the novelty doesn't wear out too quickly.

Known Issues: Some plants, signs, and doors will "pop" upon spawning.  Sorry!
