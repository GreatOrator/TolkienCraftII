These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's ruins mod.

Last Updated: 25 Nov 2014

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put them in the following Minecraft installation folders (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\*

For example, the contents of the "forest" folder go in "*\.minecraft\mods\resources\ruins\forest"

Each of these templates calls OTHER templates -- and those called templates all need to go in the templateparser folder, or it's just not going to work.

The unifying theme here so far is "really big trees."  Normally, if you want large structures to spawn easily, they either need a fairly small footprint, or you need to use max_leveling -- but a big fat tree doesn't work well with either method.  Hence, this consists of a small-footprint "structure" that's basically just a command block that uses the /testruin template to call the larger structure.

