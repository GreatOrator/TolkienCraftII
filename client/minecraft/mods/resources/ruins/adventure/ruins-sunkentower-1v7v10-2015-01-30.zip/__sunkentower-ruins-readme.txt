These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's ruins mod.

Last Updated: 30 Jan 2015

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put them in the following Minecraft installation folder (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\

SUNKEN TOWER #1:
The "meta" template (SunkenTower_1v7v10) goes in the Deep Ocean folder.  The
spawned structure template (TP_SunkenTower) goes in the 
\templateparser folder, and is called within the game.

This is a proof-of-concept experiment at summoning structures underwater,
but with "air pockets" inside, as an intermediate step toward spawning
an "underwater sunken village."  In the meantime, this at least serves
as a mini-encounter, complete with a weird monster defender and a sort of
treasure.  :)
