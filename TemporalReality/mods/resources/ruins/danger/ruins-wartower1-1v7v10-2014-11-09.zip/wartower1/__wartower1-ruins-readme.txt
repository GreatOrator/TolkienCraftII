These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's ruins mod.

Last Updated: 9 Nov 2014

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put them in the following Minecraft installation folder (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\

WAR TOWER #1:
The "meta" template (WarTower1Base_1v7v10) goes in the Plains folder.  The remainder (prefaced "TP_*") go into the templateparser folder, and are called within the game.

The idea behind this structure is that an evil sorcer has a MAGICAL tower that exists beyond the material plane.  To reach the top, you must pass each of his golem guardians and open the chest that reveals the next segment of the tower in turn.  Eventually, his inner sanctum is revealed at the top, and you get to square off against the Evil Sorcerer and his Patchwork Golems.

