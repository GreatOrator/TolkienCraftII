These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's ruins mod.

Last Updated: 14 Jan 2015

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put the folders (desert, plains, etc.) in the following Minecraft installation folder (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\

DANGER:
Structures included in this pack are intended to add interest to the environment, but also a touch of surprise and danger.  That apparently unguarded chest might be tied to a chest,
or that monster-infested house might be intended for you to take a few friends along in order to clear it.  Your mileage may vary, of course -- once you figure out the surprise,
the trap probably won't pose nearly so much danger, and with certain mod packs or a bit of tactics, you might easily clear out the monsters on your own.  I'm only organizing these
here so that those persons who DO NOT enjoy stumbling into trap-laden tombs can easily avoid them, and just stick to the "scenery" or the fairly mild "adventure" features.

For a little more variety, you might include the "Scenery" and "Adventure" sets as well, so not EVERYTHING is a death trap.
