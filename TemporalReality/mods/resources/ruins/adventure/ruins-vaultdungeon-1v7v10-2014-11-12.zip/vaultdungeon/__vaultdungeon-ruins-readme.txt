These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's Ruins mod.

Last Updated: 12 Nov 2014

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put them in the following Minecraft installation folder (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\

VAULT DUNGEON:
The "meta" template (VaultEntrance_1v7v10.tml) goes in the Plains folder.  The remainder (prefaced "TP_*") go into the templateparser folder, and are called within the game.

If proper ground is found to spawn the whole thing, this should create a small graveyard with a central mausoleum (the outer wall may spawn only in parts, or not at all), with a staircase leading down into a trapped system of catacombes.

