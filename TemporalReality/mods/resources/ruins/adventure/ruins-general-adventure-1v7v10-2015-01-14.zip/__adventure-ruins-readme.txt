These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's ruins mod.

Last Updated: 14 Jan 2015

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put the folders (desert, plains, etc.) in the following Minecraft installation folder (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\

ADVENTURE:
Structures included in this pack are intended to add interest to the environment, but also just a little bit of risk and reward.  
There might be the occasional monster spawner, and maybe a dispenser that shoots arrows or spawn eggs at you, but you won't find 
tempting treasures that set off stacks of TNT or drop lava on your head, or otherwise ruin your day with a nasty surprise.  
(At least, that's not my intent!)  Please note that there is no uniformity in difficulty: Some structures were made with the expectation 
that an intrepid explorer should either be very well-equipped and careful, or that he or she has brought a few friends along to help clear 
out the monsters.  Generally, the tumult of spiders and skeletons what whatnot will give a clue of what sort of trouble you're in store for.

Since these are a bit sparse, it's recommended that you also include the "Scenery" set for a little more variety.

Warning: The "RUINSTRIGGER" feature is used with Command Blocks extensively in many of these structures.  There is potential conflict
with Forge/Cauldron (which seems to interfere with RUINSTRIGGER), and with multiplayer servers where Command Blocks are not enabled.
There's also a known issue with the "Mo' Potions" mod (as structures with a cauldron as part of the building cause a conflict).

