These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's ruins mod.

Last Updated: 13 Jan 2015
(some villager trades tweaked to better maintain the "economy")

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put the folders in the following Minecraft installation folder (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\

If you're asked to merge folders, go ahead.  This will just add the templates to those currently in the plains and forest folders (possibly overwriting older versions of the same templates).

SHOPS:
This is a work-in-progress collection of villager shops, which might be found out in the wilderness, or deliberately spawned via /testruin in order to build up a regular village in Creative mode.  These were created more with experimentation in mind than strict play-balance, and the buildings are already mostly lit up so as to ensure that the villagers have at least some chance of survivability for a while.  They aren't quite "ruins," in that sense.

