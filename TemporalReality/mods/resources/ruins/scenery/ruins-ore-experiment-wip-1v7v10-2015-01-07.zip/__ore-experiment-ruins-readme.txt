These templates are created by Jordan Peacock (AKA Jordan_Greywolf) via AtomicStryker's ruins mod.

Last Updated: 7 Jan 2015

To use, you will need Minecraft (version 1.7.10), plus AtomicStryker's Ruins mod.

For more information:
http://www.minecraftforum.net/forums/mapping-and-modding/minecraft-mods/1282339-ruins-structure-spawning-system

For AtomicStryker's Ruins mod:
http://atomicstryker.net/ruins.php

To use these templates, put the folders (desert, plains, etc.) in the following Minecraft installation folder (exact path may vary depending upon your installation):

*\.minecraft\mods\resources\ruins\

ORE EXPERIMENT:
This is just a test for a few "ore deposit" structures meant to be combined with certain mods that have specialized ore (but which for
whatever reason aren't generating in the world as intended) in order to spawn them in clusters, possibly organized by biome, and with some
control for depth.  It's still a work in progress.


